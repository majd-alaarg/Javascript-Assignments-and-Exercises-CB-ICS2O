var firstName, lastName, birthYear, myAge; 
firstName="Williams";
lastName = "Thottungal";
birthYear = "2005";
myAge = 2020-birthYear
document.write ("My name is " +firstName +" " + lastName);
document.write ("<br>I was born in " +birthYear)
document.write ("<br> I am " +myAge +" " +"years old");