//if inclusive add one (1-100 inclusive) = Math.floor(101*Math.random()+70)
//Check for knowledge
//1. The possible values of x is in between 12 and 26.
//2. var r = Math.floor(50*Math.random()+1);
//   alert(r);
//3. var r = Math.floor(21*Math.random()-10);
//   alert(r);
//4. var r = Math.floor(82*Math.random()-67);
//   alert(r);
//5. a. 2, b. 4.5, c. 121